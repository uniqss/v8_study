#!/usr/bin/env bash
. demo_repo.sh
run git map
